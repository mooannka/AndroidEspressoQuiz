package com.sourcey.materiallogindemo;


import android.support.test.espresso.ViewInteraction;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.pressImeActionButton;
import static android.support.test.espresso.action.ViewActions.replaceText;
import static android.support.test.espresso.action.ViewActions.scrollTo;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class RegisterSuccess {

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void registerSuccess() {
        pressBack();

        ViewInteraction appCompatTextView = onView(
                allOf(withId(R.id.link_signup), withText("No account yet? Create one")));
        appCompatTextView.perform(scrollTo(), click());

        ViewInteraction appCompatEditText = onView(
                withId(R.id.input_name));
        appCompatEditText.perform(scrollTo(), replaceText("ann"), closeSoftKeyboard());

        ViewInteraction appCompatEditText2 = onView(
                withId(R.id.input_address));
        appCompatEditText2.perform(scrollTo(), replaceText("bkk"), closeSoftKeyboard());

        ViewInteraction appCompatEditText3 = onView(
                withId(R.id.input_email));
        appCompatEditText3.perform(scrollTo(), replaceText("k@k.com"), closeSoftKeyboard());

        ViewInteraction appCompatEditText4 = onView(
                allOf(withId(R.id.input_email), withText("k@k.com")));
        appCompatEditText4.perform(pressImeActionButton());

        ViewInteraction appCompatEditText5 = onView(
                withId(R.id.input_mobile));
        appCompatEditText5.perform(scrollTo(), replaceText("0894669211"), closeSoftKeyboard());

        ViewInteraction appCompatEditText6 = onView(
                allOf(withId(R.id.input_mobile), withText("0894669211")));
        appCompatEditText6.perform(pressImeActionButton());

        ViewInteraction appCompatEditText7 = onView(
                withId(R.id.input_password));
        appCompatEditText7.perform(scrollTo(), replaceText("ttttttt"), closeSoftKeyboard());

        ViewInteraction appCompatEditText8 = onView(
                allOf(withId(R.id.input_password), withText("ttttttt")));
        appCompatEditText8.perform(pressImeActionButton());

        ViewInteraction appCompatEditText9 = onView(
                withId(R.id.input_reEnterPassword));
        appCompatEditText9.perform(scrollTo(), replaceText("ttttttt"), closeSoftKeyboard());

        ViewInteraction appCompatEditText10 = onView(
                allOf(withId(R.id.input_reEnterPassword), withText("ttttttt")));
        appCompatEditText10.perform(pressImeActionButton());

        ViewInteraction appCompatTextView2 = onView(allOf(withId(R.id.link_login), withText("Already a member? Login")));

        ViewInteraction appCompatButton = onView(
                allOf(withId(R.id.btn_signup), withText("Create Account")));
        appCompatButton.perform(scrollTo(), click());


        /*try {
            Thread.sleep(2000);
            MainActivity activity = mActivityTestRule.getActivity();
            onView(withText(R.string.msgCreating)).inRoot(withDecorView(not(is(activity.getWindow().getDecorView())))).check(matches(isDisplayed()));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/


        //Validate Application screen
        ViewInteraction textView = onView(allOf(withText("Material Login Example"),
                        childAtPosition(allOf(withId(R.id.action_bar), childAtPosition(withId(R.id.action_bar_container), 0)), 0),
                        isDisplayed()));
        textView.check(matches(withText("Material Login Example")));

        ViewInteraction textView2 = onView(allOf(withText("Hello world!"),
                        childAtPosition(childAtPosition(withId(android.R.id.content), 0), 0),
                        isDisplayed()));
        textView2.check(matches(withText("Hello world!")));

        ViewInteraction button = onView(allOf(withId(R.id.btn_logout),
                        childAtPosition(childAtPosition(withId(android.R.id.content), 0), 1),
                        isDisplayed()));
        button.check(matches(isDisplayed()));


    }

    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

        @Override
        public boolean matchesSafely(View view) {
            ViewParent parent = view.getParent();
            return parent instanceof ViewGroup && parentMatcher.matches(parent)
                    && view.equals(((ViewGroup) parent).getChildAt(position));
        }
    };
}
}
